/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Tony
 */
public class PaletteTest {
    
    public PaletteTest() {
    }

    /**
     * Test of getWeight method, of class Palette.
     */
    @Test
    public void testGetWeight() {
        System.out.println("getWeight");
        Palette instance = null;
        double expResult = 0.0;
        double result = instance.getWeight();
        assertEquals(expResult, result, 0.0);
    }

    /**
     * Test of getHeight method, of class Palette.
     */
    @Test
    public void testGetHeight() {
        System.out.println("getHeight");
        Palette instance = null;
        double expResult = 0.0;
        double result = instance.getHeight();
        assertEquals(expResult, result, 0.0);
    }
    
}
