/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Tony
 */
public class BrickTest {
    
    public BrickTest() {
    }

    /**
     * Test of getSurfaceArea method, of class Brick.
     */
    @Test
    public void testGetSurfaceArea() {
        System.out.println("getSurfaceArea");
        Brick instance = new Brick(1, 2, 3);
        double expResult = ( 1*2 + 1*3 + 2*3 ) * 2;
        double result = instance.getSurfaceArea();
        assertEquals(expResult, result, 0.0);
    }

    /**
     * Test of getWeight method, of class Brick.
     */
    @Test
    public void testGetWeight() {
        System.out.println("getWeight");
        Brick instance = new Brick(1, 2, 3);
        double expResult = (6 * 2) / 1000;
        double result = instance.getWeight();
        assertEquals(expResult, result, 0.0);
    }

    /**
     * Test of getVolume method, of class Brick.
     */
    @Test
    public void testGetVolume() {
        System.out.println("getVolume");
        Brick instance = new Brick(1, 2, 3);
        int expResult = 6;
        int result = instance.getVolume();
        assertEquals(expResult, result);
    }

    /**
     * Test of getHeight method, of class Brick.
     */
    @Test
    public void testGetHeight() {
        System.out.println("getHeight");
        Brick instance = new Brick(1, 2, 3);
        double expResult = 1.0;
        double result = instance.getHeight();
        assertEquals(expResult, result, 0.0);
    }
    
}
