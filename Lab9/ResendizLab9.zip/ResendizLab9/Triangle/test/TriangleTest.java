/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Tony
 */
public class TriangleTest {
    
    public TriangleTest() {
    }

    /**
     * Test of classify method, of class Triangle.
     */
    @Test
    public void testClassify() {
        System.out.println("classify");
        Triangle instance = new Triangle(2, 2, 3);
        String expResult = "isosceles";
        String result = instance.classify();
        assertEquals(expResult, result);
    }
    
}
