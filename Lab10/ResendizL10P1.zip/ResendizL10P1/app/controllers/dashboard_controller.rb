class DashboardController < ApplicationController
	def index
	end
end